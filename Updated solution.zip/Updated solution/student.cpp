#include "student.h"
#include <iostream>

// Constructor
Student::Student(std::string studentID, std::string firstName, std::string lastName,
    std::string emailAddress, int age, int daysInCourse1, int daysInCourse2,
    int daysInCourse3, DegreeProgram degreeProgram) {
    this->studentID = studentID;
    this->firstName = firstName;
    this->lastName = lastName;
    this->emailAddress = emailAddress;
    this->age = age;
    this->daysInCourse[0] = daysInCourse1;
    this->daysInCourse[1] = daysInCourse2;
    this->daysInCourse[2] = daysInCourse3;
    this->degreeProgram = degreeProgram;
}

// Accessors
std::string Student::getStudentID() { return studentID; }
std::string Student::getFirstName() { return firstName; }
std::string Student::getLastName() { return lastName; }
std::string Student::getEmailAddress() { return emailAddress; }
int Student::getAge() { return age; }
int* Student::getDaysInCourse() { return daysInCourse; }
DegreeProgram Student::getDegreeProgram() { return degreeProgram; }

// Print student information
void Student::print() {
    std::cout << "Student ID: " << getStudentID() << "\tFirst Name: " << getFirstName()
        << "\tLast Name: " << getLastName() << "\tAge: " << getAge()
        << "\tDays in Course: (" << getDaysInCourse()[0] << ", " << getDaysInCourse()[1]
        << ", " << getDaysInCourse()[2] << ")\tDegree Program: ";
    switch (getDegreeProgram()) {
    case SECURITY:
        std::cout << "Security";
        break;
    case NETWORK:
        std::cout << "Network";
        break;
    case SOFTWARE:
        std::cout << "Software";
        break;
    }
    std::cout << std::endl;
}
