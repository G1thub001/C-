#include "roster.h"
#include <iostream>

// Constructor
Roster::Roster() {
    lastIndex = -1;
    for (int i = 0; i < maxSize; ++i) {
        classRosterArray[i] = nullptr;
    }
}

// Destructor
Roster::~Roster() {
    for (int i = 0; i <= lastIndex; ++i) {
        delete classRosterArray[i];
    }
}

// Functions
void Roster::add(std::string studentID, std::string firstName, std::string lastName,
    std::string emailAddress, int age, int daysInCourse1, int daysInCourse2,
    int daysInCourse3, DegreeProgram degreeProgram) {
    if (lastIndex < maxSize - 1) {
        lastIndex++;
        classRosterArray[lastIndex] = new Student(studentID, firstName, lastName,
            emailAddress, age, daysInCourse1, daysInCourse2, daysInCourse3, degreeProgram);
    }
}

void Roster::remove(std::string studentID) {
    bool found = false;
    for (int i = 0; i <= lastIndex; ++i) {
        if (classRosterArray[i]->getStudentID() == studentID) {
            found = true;
            delete classRosterArray[i];
            classRosterArray[i] = classRosterArray[lastIndex];
            lastIndex--;
            break;
        }
    }
    if (!found) {
        std::cout << "Error: Student with ID " << studentID << " not found." << std::endl;
    }
}

void Roster::printAll() {
    for (int i = 0; i <= lastIndex; ++i) {
        classRosterArray[i]->print();
    }
}

void Roster::printAverageDaysInCourse(std::string studentID) {
    Student* student = getStudent(studentID);
    if (student) {
        int* days = student->getDaysInCourse();
        int average = (days[0] + days[1] + days[2]) / 3;
        std::cout << "Student ID: " << studentID << ", average days in course is: " << average << std::endl;
    }
}

void Roster::printInvalidEmails() {
    for (int i = 0; i <= lastIndex; ++i) {
        std::string email = classRosterArray[i]->getEmailAddress();
        if (!isValidEmail(email)) {
            std::cout << email << " is an invalid email address." << std::endl;
        }
    }
}

void Roster::printByDegreeProgram(DegreeProgram degreeProgram) {
    for (int i = 0; i <= lastIndex; ++i) {
        if (classRosterArray[i]->getDegreeProgram() == degreeProgram) {
            classRosterArray[i]->print();
        }
    }
}

// Helper functions
Student* Roster::getStudent(std::string studentID) {
    for (int i = 0; i <= lastIndex; ++i) {
        if (classRosterArray[i]->getStudentID() == studentID) {
            return classRosterArray[i];
        }
    }
    return nullptr;
}

bool Roster::isValidEmail(std::string emailAddress) {
    // Simple validation for demonstration purposes
    return (emailAddress.find('@') != std::string::npos && emailAddress.find('.') != std::string::npos && emailAddress.find(' ') == std::string::npos);
}
