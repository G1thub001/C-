#include <iostream>
#include "roster.h"

int main() {
    Roster classRoster;

    // Add students to the roster
    classRoster.add("A1", "John", "Smith", "John1989@gm ail.com", 20, 30, 35, 40, SECURITY);
    classRoster.add("A2", "Suzan", "Erickson", "Erickson_1990@gmail.com", 19, 50, 30, 40, NETWORK);
    classRoster.add("A3", "Jack", "Napoli", "The_lawyer99yahoo.com", 19, 20, 40, 33, SOFTWARE);
    classRoster.add("A4", "Erin", "Black", "Erin.black@comcast.net", 22, 50, 58, 40, SECURITY);
    classRoster.add("A5", "fName", "Lname", "Your valid email address", 25, 30, 35, 40, SOFTWARE);

    // Print all students
    std::cout << "Printing all students:" << std::endl;
    classRoster.printAll();

    // Print invalid emails
    std::cout << "\nPrinting invalid emails:" << std::endl;
    classRoster.printInvalidEmails();

    // Print average days in course for a student
    std::cout << "\nPrinting average days in course for students "<< std::endl;
    for (int i = 0; i < 5; ++i) {
        std::string studentID = "A" + std::to_string(i + 1);
        classRoster.printAverageDaysInCourse(studentID);
        std::cout << std::endl; // Add a newline for readability
    }

    // Print students in the SOFTWARE degree program
    std::cout << "\nPrinting students in the SOFTWARE degree program:" << std::endl;
    classRoster.printByDegreeProgram(SOFTWARE);

    // Remove student A3
    std::cout << "\nRemoving student A3:" << std::endl;
    classRoster.remove("A3");

    // Try to remove student A3 again (should print error message)
    std::cout << "\nTrying to remove student A3 again:" << std::endl;
    classRoster.remove("A3");

    // Print all students after removal
    std::cout << "\nPrinting all students after removal:" << std::endl;
    classRoster.printAll();

    std::cout << "\nDONE" << std::endl;

    return 0;
}
