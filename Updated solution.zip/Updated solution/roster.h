#pragma once
#include <string>
#include "degree.h"
#include "student.h"

class Roster {
public:
    // Constructor & Destructor
    Roster();
    ~Roster();

    // Functions
    void add(std::string studentID, std::string firstName, std::string lastName,
        std::string emailAddress, int age, int daysInCourse1, int daysInCourse2,
        int daysInCourse3, DegreeProgram degreeProgram);
    void remove(std::string studentID);
    void printAll();
    void printAverageDaysInCourse(std::string studentID);
    void printInvalidEmails();
    void printByDegreeProgram(DegreeProgram degreeProgram);

private:
    Student* classRosterArray[5];
    int lastIndex;
    const static int maxSize = 5;

    // Helper functions
    Student* getStudent(std::string studentID);
    bool isValidEmail(std::string emailAddress);
};
